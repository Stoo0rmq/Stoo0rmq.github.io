# Favicons

These sample favicons have been generated at http://realfavicongenerator.net/.

To add your own simply visit http://realfavicongenerator.net/ and
generate a new set of favicons (change the path option to `/favicons/`)
and replace all of the files in this folder. Then update the favicon section in
the [head.html](../_includes/head.html) include with the generated meta tags.
